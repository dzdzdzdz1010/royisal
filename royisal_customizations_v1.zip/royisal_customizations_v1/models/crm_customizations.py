from odoo import fields,models,api
from odoo.exceptions import UserError,ValidationError

class CRMLeadCustomizations(models.Model):
    _inherit = 'crm.lead'

    interested_id = fields.Many2one(
        'crm.tag',
        string='What you are interested in?',
        context={'type': 'interest'},
        domain=[('type', '=', 'interest')],
    )

    business_status = fields.Selection([
        ('In the business', 'In the business'),
        ('Start Up', 'Start Up'),
        ('N/A', 'N/A'),
    ])

    business_type_id = fields.Many2one(
        'crm.tag',
        string="Business Type",
        context={'type': 'business_type'},
        domain=[('type', '=', 'business_type')],
    )

    employee_count = fields.Selection([
        ('1-10', '1-10'),
        ('11-50', '11-50'),
        ('51-200', '51-200'),
        ('201-500', '201-500'),
        ('500_up', '500+'),
    ], string='Employee Count')

    deal_pipeline = fields.Selection([
        ('Ecommerce Pipeline', 'Ecommerce Pipeline'),
        ('Sales Pipeline', 'Sales Pipeline'),
        ('Events and Exhibitions','Events and Exhibitions'),
    ])


class CRMTagType(models.Model):
    _inherit = 'crm.tag'

    type = fields.Selection([
        ('None', 'None'),
        ('interest', 'Interest'),
        ('business_type', 'Business Type'),
    ])

    @api.model
    def create(self, vals):
        res = super(CRMTagType, self).create(vals)
        type = self.env.context.get('type', False)
        if type:
            if type == 'interest':
                res.type = 'interest'
            elif type == 'business_type':
                res.type = 'business_type'
        return res

